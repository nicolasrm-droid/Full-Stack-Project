const mongoose = require('mongoose');
const {
    Schema
} = mongoose;

const bikeSchema = new Schema({
    name: {
        type: String,
        required: true
    },
    correo: {
        type: String,
        required: true
    },
    password: {
        type: alphanumeric,
       required: true
    }

});

module.exports = mongoose.model('bikes', bikeSchema)