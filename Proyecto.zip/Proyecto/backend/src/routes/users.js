const express = require('express');
const router = express.Router();

router.get('/users/singIn', (req, res) => {
    res.send('ingresando a la aplicacion ')
});

router.get('/users/Registro', (req, res) => {
    res.render('users/registro')
});
router.post('/users/registro', (req, res) => {
    const {
        nombres,
        correo,
        contraseña,
        confirme_contraseña
    } = req.body;

    const errors = [];
    if (contraseña != confirme_contraseña) {
        errors.push({
            text: 'su contraseña no coincide '
        });

    }
    if (contraseña.length > 4) {
        errors.push({
            text: 'la contraseña debe tener al menos 4 numeros '
        });

    }

    res.send('ok')
})
module.exports = router;