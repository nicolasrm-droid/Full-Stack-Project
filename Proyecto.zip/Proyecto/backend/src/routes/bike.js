const express = require('express');
const Bikes = require('../models/Bikes');
const router = express.Router();

const Bike = require('../models/Bikes');

router.get('/bike/add-bike', (req, res) => {
    res.render('bike/new-bike')
});

router.post('/bike/new-bike', async (req, res) => {
    const {
        title,
        descripcion
    } = req.body;
    const errors = [];

    if (!title) {
        errors.push({
            text: ' Por favor inserte un titulo'
        });
    }
    if (!descripcion) {
        errors.push({
            text: 'escriba una descripcion'
        });
    }
    if (errors.length > 0) {
        res.render('bike/new-bike', {
            errors,
            title,
            descripcion
        });
    } else {
        const newBike = new Bike({
            title,
            descripcion
        });
        await newBike.save();
        res.redirect('/bikes')
    }

});
router.get('/bikes', async (req, res) => {
    await Bike.find()
        .sort({
            date: 'desc'
        })
        .then(documentos => {
            const contexto = {
                bikes: documentos.map(documento => {
                    return {
                        title: documento.title,
                        descripcion: documento.descripcion
                    }
                })
            }
            res.render('bike/all-bikes', {
                bikes: contexto.bikes
            })
        })



})
router.delete('/bikes/delete/:id', (req, res) => {
    console.log('req.params.id')
    res.send('ok')
});





module.exports = router;